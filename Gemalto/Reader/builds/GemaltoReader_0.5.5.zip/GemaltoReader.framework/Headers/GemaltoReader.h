//
//  GemaltoReader.h
//  GemaltoReader
//
//  Created by Jakub Mejtský on 06/10/2019.
//  Copyright © 2019 AHEAD iTec. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for GemaltoReader.
FOUNDATION_EXPORT double GemaltoReaderVersionNumber;

//! Project version string for GemaltoReader.
FOUNDATION_EXPORT const unsigned char GemaltoReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GemaltoReader/PublicHeader.h>


