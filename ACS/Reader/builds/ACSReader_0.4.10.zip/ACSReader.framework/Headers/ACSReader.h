//
//  ACSReader.h
//  ACSReader
//
//  Created by David Bielik on 30/10/2018.
//  Copyright © 2018 ahead-itec. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ACSReader.
FOUNDATION_EXPORT double ACSReaderVersionNumber;

//! Project version string for ACSReader.
FOUNDATION_EXPORT const unsigned char ACSReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ACSReader/PublicHeader.h>


