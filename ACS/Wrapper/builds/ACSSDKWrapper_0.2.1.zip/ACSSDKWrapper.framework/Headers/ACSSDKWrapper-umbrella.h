#ifdef __OBJC__
#import <UIKit/UIKit.h>
#else
#ifndef FOUNDATION_EXPORT
#if defined(__cplusplus)
#define FOUNDATION_EXPORT extern "C"
#else
#define FOUNDATION_EXPORT extern
#endif
#endif
#endif

#import "ABTAcr1255uj1Reader.h"
#import "ABTAcr3901us1Reader.h"
#import "ABTBluetoothReader.h"
#import "ABTBluetoothReaderManager.h"
#import "ABTError.h"

FOUNDATION_EXPORT double ACSSDKWrapperVersionNumber;
FOUNDATION_EXPORT const unsigned char ACSSDKWrapperVersionString[];

