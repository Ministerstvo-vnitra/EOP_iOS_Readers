//
//  FeitianReader.h
//  FeitianReader
//
//  Created by Jakub Mejtský on 30/10/2018.
//  Copyright © 2018 AHEAD iTec, s.r.o. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FeitianReader.
FOUNDATION_EXPORT double FeitianReaderVersionNumber;

//! Project version string for FeitianReader.
FOUNDATION_EXPORT const unsigned char FeitianReaderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FeitianReader/PublicHeader.h>


